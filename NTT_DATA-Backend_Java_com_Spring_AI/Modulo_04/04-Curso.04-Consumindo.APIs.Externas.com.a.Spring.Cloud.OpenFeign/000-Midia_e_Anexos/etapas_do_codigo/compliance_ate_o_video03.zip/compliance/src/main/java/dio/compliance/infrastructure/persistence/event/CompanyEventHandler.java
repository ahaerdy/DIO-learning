package dio.compliance.infrastructure.persistence.event;

import dio.compliance.infrastructure.persistence.entity.CompanyEntity;
import org.slf4j.LoggerFactory;
import org.springframework.data.rest.core.annotation.HandleAfterCreate;
import org.springframework.data.rest.core.annotation.RepositoryEventHandler;
import org.springframework.stereotype.Component;

import org.slf4j.Logger;

@Component
@RepositoryEventHandler
public class CompanyEventHandler {

    private static final Logger LOG = LoggerFactory.getLogger(CompanyEventHandler.class);

    @HandleAfterCreate
    public void handleAfterCreateEvent(CompanyEntity entity) {
        LOG.info("handleAfterCreateEvent {}", entity);
    }
}